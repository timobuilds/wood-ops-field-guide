# Article-to-skill map

All 58 entries in the supplied publisher index plus the photographed column. The job names and objective format are editorial adaptations. Multiple routes indicate complementary uses. Order follows the supplied index.

1. “Plant Tours: A shortcut to operational excellence” (Sepp Gmeiner, Woodworking Canada) — Reconstruct the plant’s flow after the walk and identify one practice worth testing back home. `read-plant`

2. “Operational Excellence: But where and how do you start?” (Sepp Gmeiner, Woodworking Canada) — Use a ready-for-production check, daily floor meeting and rework review to restore discipline under pressure. `set-direction`

3. “Don't rely on luck alone” (Sepp Gmeiner, Woodworking Canada) — Translate long-range aims into one page of priorities, owners and scenarios across departments. `set-direction`

4. “Ten questions to ask before you change your plant layout” (Sepp Gmeiner, Woodworking Canada) — Check business fit, operating model, supply and information flow before moving machines. `design-layout`

5. “Start with strategy: Avoiding tactical traps in the pursuit of excellence” (Sepp Gmeiner, Woodworking Canada) — Evaluate strategy and operational capabilities together before selecting isolated tactics. `set-direction`

6. “Equipment justification: A practical guide” (Sepp Gmeiner, Woodworking Canada) — Compare alternatives against the fully installed cost and benefits that can actually be realized. `evaluate-equipment`

7. “Just call it common sense” (Sepp Gmeiner, Woodworking Canada) — Start by making one task easier; sustain progress with knowledge, leadership and time. `run-lean-trial`

8. “Maximizing the benefits of plant tours” (Sepp Gmeiner, Woodworking Canada) — Give a peer or supplier visit a specific question and compare notes promptly afterward. `read-plant`, `decide-make-or-buy`, `benchmark-plants`

9. “Where do trained workers come from?” (Sepp Gmeiner, Woodworking Canada) — Build a person-by-task proficiency matrix and close coverage gaps through demonstrated training. `build-skill-coverage`

10. “Getting more done: The power of fit and complete” (Sepp Gmeiner, Woodworking Canada) — Trace incomplete shipments upstream through assembly to the first missing or unusable input. `check-job-readiness`

11. “Unlocking the potential of Lean manufacturing: Strategies for success” (Sepp Gmeiner, Woodworking Canada) — Identify customer-value losses; use workplace organization as a starting point and reduce changeovers to permit smaller batches. `run-lean-trial`

12. “In pursuit of efficiency - The power of efficiency = E4” (Sepp Gmeiner, Woodworking Canada) — Look for efficiency opportunities across people, materials, process and technology together. `run-lean-trial`, `improve-material-yield`

13. “Making quality a priority” (Sepp Gmeiner, Woodworking Canada) — Rank the cost of failures and select a quality-system practice that addresses the largest actionable loss. `reduce-defects`, `plan-finishing`

14. “Where to look for the next boost in productivity?” (Sepp Gmeiner, Woodworking Canada) — At assembly, measure time spent identifying, sorting and fetching parts before considering automation. `check-job-readiness`, `evaluate-equipment`

15. “Improving your layout” (Sepp Gmeiner, Woodworking Canada) — Map buffers, handling and fixed equipment, then stage a layout move around actual flow. `design-layout`

16. “Equipment justification” (Sepp Gmeiner, Woodworking Canada) — Compare capital invested with the realistic alternative and distinguish financial returns from qualitative benefits. `evaluate-equipment`

17. “Here are some keys to achieve operations excellence” (Sepp Gmeiner, Woodworking Canada) — Assess operations in the context of company-wide performance and strategy. `set-direction`

18. “Pull!” (Sepp Gmeiner, Woodworking Canada) — Limit upstream release when a defined buffer is full; support the downstream operation pulling work. `schedule-constraint`

19. “Only by setting a goal, will you find a way!” (Sepp Gmeiner, Woodworking Canada) — Connect short-, medium- and long-term goals to concrete projects across business functions. `set-direction`

20. “How sure are you about your estimating?” (Sepp Gmeiner, Woodworking Canada) — Check labour-time assumptions, yield, indirect materials and overhead before trusting an estimate. `improve-material-yield`, `cost-an-order`

21. “Know your bottleneck and improve your scheduling” (Sepp Gmeiner, Woodworking Canada) — Schedule to the product mix the limiting operation can complete; machine counts alone hide overload. `schedule-constraint`

22. “Basics first: Fit & complete” (Sepp Gmeiner, Woodworking Canada) — Confirm that every required input fits and is available where and when the next process needs it. `check-job-readiness`

23. “Do you have facts – or just an opinion?” (Sepp Gmeiner, Woodworking Canada) — Benchmark using consistent definitions, credible samples, subdivisions, confidentiality and timely reporting. `review-scoreboard`, `benchmark-plants`

24. “Lean – Three key elements” (Sepp Gmeiner, Woodworking Canada) — Check three prerequisites for Lean implementation: know-how, leadership and protected time. `run-lean-trial`

25. “Make or buy” (Sepp Gmeiner, Woodworking Canada) — Compare existing in-house work, constraint relief and new in-house capability as different sourcing decisions. `decide-make-or-buy`

26. “How is your production doing?” (Sepp Gmeiner, Woodworking Canada) — Share a small set of measures with operators and review averages and trends alongside daily results. `review-scoreboard`

27. “Plant tours – A simple tool to learn” (Sepp Gmeiner, Woodworking Canada) — Prepare a visit around a decision and use the observations for peer, supplier or internal learning. `read-plant`, `benchmark-plants`

28. “Where do we start?” (Sepp Gmeiner, Woodworking Canada) — Expose hidden constraints by reducing unnecessary buffers and start with an actionable improvement. `set-direction`, `schedule-constraint`

29. “People are your most critical resource” (Sepp Gmeiner, Woodworking Canada) — Identify dependence on scarce people and plan training and workforce coverage. `build-skill-coverage`

30. “Pick a goal and you will find a way” (Sepp Gmeiner, Woodworking Canada) — Set the destination before choosing projects, owners and measures of progress. `set-direction`

31. “Production scheduling” (Sepp Gmeiner, Woodworking Canada) — Release manageable time buckets that can finish, balanced by capacity and mix. `schedule-constraint`

32. “Complete and fit: The starting point for productivity” (Sepp Gmeiner, Woodworking Canada) — Verify fit and availability across information, tools, material, method and workforce. `check-job-readiness`

33. “Lean manufacturing: Easier, better, faster, cheaper” (Sepp Gmeiner, Woodworking Canada) — Make daily work easier for operators while preserving safety and quality. `run-lean-trial`

34. “Lean manufacturing: It really works” (Sepp Gmeiner, Woodworking Canada) — Use experience from actual Lean adoption to design a manageable first improvement. `run-lean-trial`

35. “Industry 4.0: Don't be left behind” (Sepp Gmeiner, Woodworking Canada) — Map the interfaces and data needed to connect design, business software and machines. `simplify-order-engineering`

36. “Cut and drill versus nesting” (Sepp Gmeiner, Woodworking Canada) — Compare nesting with cutting and drilling using volume, standardization, yield and sequencing. `evaluate-equipment`

37. “Lean manufacturing: How often have you tried?” (Sepp Gmeiner, Woodworking Canada) — Investigate stalled Lean efforts through management participation, ownership, training and sustained effort. `run-lean-trial`

38. “Pull vs. push” (Sepp Gmeiner, Woodworking Canada) — Use downstream consumption to pace upstream work; local utilization can inflate inventory. `schedule-constraint`

39. “What you measure gets attention, and what gets attention will improve” (Sepp Gmeiner, Woodworking Canada) — Give workers a visible score and interpret trends in customer and production outcomes. `review-scoreboard`

40. “Plant tours – How to read a plant” (Sepp Gmeiner, Woodworking Canada) — Observe scheduling, space, quality and visual controls during a purposeful plant visit. `read-plant`, `benchmark-plants`

41. “What are you going to change now?” (Sepp Gmeiner, Woodworking Canada) — Make strategic priorities actionable through leadership, delegation and room for employees to improve work. `set-direction`, `run-lean-trial`

42. “Working in the business vs. working on the business” (Sepp Gmeiner, Woodworking Canada) — Protect management time to develop the operation alongside the demands of running it. `set-direction`

43. “Fit & Complete - Productivity Improvement 101” (Sepp Gmeiner, Woodworking Canada) — Use interrupted assembly, full buffers and frustrated workers to find fit-and-completeness failures. `check-job-readiness`

44. “Which product makes you money? Do you know your production cost?” (Sepp Gmeiner, Woodworking Canada) — Update the product costing model and examine which assumptions shift margin across products. `cost-an-order`, `decide-make-or-buy`

45. “How do you know you are doing a good job?” (Sepp Gmeiner, Woodworking Canada) — Agree on objectives and establish a credible baseline and reporting cycle. `review-scoreboard`

46. “Kaikaku or Kaizen – Questions you need to answer before you change the layout” (Sepp Gmeiner, Woodworking Canada) — Choose the scale of layout change after considering engineering, supply, systems, technology and sales. `design-layout`

47. “Increase customer satisfaction and reduce your cost at the same time - a win-win situation” (Sepp Gmeiner, Woodworking Canada) — Use agreed acceptance limits, inspection feedback and cross-functional review to prevent recurrence. `reduce-defects`

48. “Finishing is a complex issue and proper planning is essential” (Sepp Gmeiner, Woodworking Canada) — Align substrate, coating, process steps, volume, equipment and supplier trials before specifying the line. `plan-finishing`

49. “It is crucial to develop your company's knowledge base” (Sepp Gmeiner, Woodworking Canada) — Develop knowledge internally through cross-training, peer learning and sharing what staff learn. `build-skill-coverage`

50. “The struggle with mass customization” (Sepp Gmeiner, Woodworking Canada) — Measure the front-office work of converting customer choices into production instructions. `simplify-order-engineering`

51. “Improve by asking the right questions” (Sepp Gmeiner, Woodworking Canada) — Use the expediter’s record to identify repeat causes of stoppages and test the suspected bottleneck. `check-job-readiness`

52. “Industry 4.0: The Fourth Industrial Revolution” (Sepp Gmeiner, Woodworking Canada) — Assess integration readiness against the business need and the plant’s present capabilities. `simplify-order-engineering`

53. “Stop doing the same thing, embrace change” (Sepp Gmeiner, Woodworking Canada) — Pick a destination, test whether initiatives advance it, and break large changes into smaller steps. `set-direction`

54. “Defining the right metrics for your company” (Sepp Gmeiner, Woodworking Canada) — Choose measures around customer needs and the constraint; tailor the review to each level of the plant. `review-scoreboard`

55. “The importance of process mapping” (Sepp Gmeiner, Woodworking Canada) — Map the actual process with participants before redesigning handoffs and information flow. `read-plant`, `simplify-order-engineering`

56. “Get a huge productivity boost by working on the basics” (Sepp Gmeiner, Woodworking Canada) — Work backward from the limiting operation to eliminate recurring losses of fit and availability. `check-job-readiness`

57. “Plant tours and how to read a plant” (Sepp Gmeiner, Woodworking Canada) — Compare independent observers’ impressions and verify hypotheses about flow, controls and working conditions. `read-plant`, `benchmark-plants`

58. “Solid wood waste reduction” (Sepp Gmeiner, Woodworking Canada) — Measure usable yield over a meaningful period, including grade, defects, machining losses and purchased cost. `improve-material-yield`

59. Being busy is not the same as being productive or efficient, Woodworking Canada, September/October 2026, pp. 42–43 (supplied print pages) — Use three to five worker-owned measures tied to decisions; preserve the original promise date and review trends. `review-scoreboard`, `benchmark-plants`
